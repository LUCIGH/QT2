﻿namespace QT2
{
    internal static class CurrentUser
    {
        public static User curUser { get; set; }

    }
}
