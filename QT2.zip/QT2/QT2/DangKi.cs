﻿using System.Data;
using System.Data.SqlClient;

namespace QT2
{
    public partial class DangKi : Form
    {
        SqlConnection connect = new SqlConnection(@"Data Source=lucigh\mssqlserver01;Initial Catalog=PHANMEMDIEMDANH;Integrated Security=True;"); 
        public DangKi()
        {
            InitializeComponent();
        }

        private void signup_exit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void signup_btn_Click(object sender, EventArgs e)
        {
            if (signup_password.Text == "" || signup_username.Text == ""
                || signup_email.Text == "")
            {
                MessageBox.Show("Hãy điền đầy đủ thông tin của bạn", "Error Message", MessageBoxButtons.OK);
            }
            else
            {
                try
                {
                    connect.Open();
                    String kiemtraEmail = @"SELECT COUNT(*) FROM GIANGVIEN WHERE EMAIL = @email";
                    String kiemtraUsername = @"SELECT COUNT(*) FROM GIANGVIEN WHERE USERNAME = @username";
                    String themGiangVien = @"MERGE INTO GIANGVIEN AS TARGET
                                    USING (SELECT @email AS EMAIL , @username AS USERNAME) AS SOURCE
                                    ON TARGET.EMAIL = SOURCE.EMAIL OR TARGET.USERNAME = SOURCE.USERNAME
                                    WHEN NOT MATCHED BY TARGET THEN
                                         INSERT (EMAIL,USERNAME,PWD) VALUES (SOURCE.EMAIL,SOURCE.USERNAME,@pwd);";
                    using (SqlCommand cmd = new SqlCommand(kiemtraEmail, connect))
                    {
                        cmd.Parameters.AddWithValue("@email", signup_email.Text);
                        int cnt = (int)cmd.ExecuteScalar();

                        if(cnt > 0)
                        {
                            MessageBox.Show("Email đã được sử dụng");
                            return;
                        }

                    };

                    using (SqlCommand cmd = new SqlCommand(kiemtraUsername, connect))
                    {
                        cmd.Parameters.AddWithValue("@username", signup_username.Text);
                        int cnt = (int)cmd.ExecuteScalar();

                        if (cnt > 0)
                        {
                            MessageBox.Show("Tên đăng nhập đã được sử dụng");
                            return;
                        }

                    };

                    using (SqlCommand cmd = new SqlCommand(themGiangVien, connect))
                    {
                        cmd.Parameters.AddWithValue("@email", signup_email.Text);
                        cmd.Parameters.AddWithValue("@username", signup_username.Text);
                        cmd.Parameters.AddWithValue("@pwd", signup_password.Text);
                        int affectedRows = cmd.ExecuteNonQuery();

                        if (affectedRows > 0)
                        {
                            MessageBox.Show("Đăng kí thành công");
                            DangNhap dangnhap = new DangNhap();
                            dangnhap.ShowDialog();
                            this.Close();
                        }
                    };
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error conecting database" + ex, "Error Message", MessageBoxButtons.OK);
                }
                finally
                {
                    connect.Close();
                }
            }

        }

        private void signup_showPass_CheckedChanged(object sender, EventArgs e)
        {
            if (signup_showPass.Checked)
            {
                signup_password.PasswordChar = '\0';
            }
            else
            {
                signup_password.PasswordChar = '*';
            }
        }

        private void signup_loginHere_Click(object sender, EventArgs e)
        {
            DangNhap sForm = new DangNhap();
            sForm.ShowDialog();

            this.Close();
        }
    }
}
