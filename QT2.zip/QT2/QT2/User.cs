﻿namespace QT2
{
    internal class User
    {
        public int id { get; set; }
        public string tendangnhap { get; set; }
        public string email { get; set; }
    }
}
