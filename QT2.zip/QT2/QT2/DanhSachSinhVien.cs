﻿using OfficeOpenXml;
using System.Data.SqlClient;

namespace QT2
{
    public partial class DanhSachSinhVien : Form
    {
        SqlConnection connect = new SqlConnection(@"Data Source=lucigh\mssqlserver01;Initial Catalog=PHANMEMDIEMDANH;Integrated Security=True;");
        public DanhSachSinhVien()
        {
            InitializeComponent();
        }

        private void DanhSachSinhVien_Load(object sender, EventArgs e)
        {
            try
            {
                connect.Open();
                String danhSachLop = "SELECT * FROM LOP WHERE ID = @id";
                using (SqlCommand cmd = new SqlCommand(danhSachLop, connect))
                {
                    cmd.Parameters.AddWithValue("@id",CurrentUser.curUser.id);
                    SqlDataReader sqlDataReader = cmd.ExecuteReader();
                    if (sqlDataReader.HasRows)
                    {
                        while (sqlDataReader.Read())
                        {
                            string malop = sqlDataReader["MALOP"].ToString();
                            dslop_combobox.Items.Add(malop);
                        }
                    }
                    else
                    {
                        MessageBox.Show("Danh sách lớp trống, vui lòng tạo lớp mới.");
                        this.Close();
                    }
                };
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi kết nối: " + ex.Message);
            }
            finally
            {
                connect.Close();
            }

        }

        private void chonfile_btn_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog()
            {
                Filter = "Excel files | *.xlsx; *.xls",
                Title = "Chọn danh sách sinh viên (Excel)"
            };

            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                string filePath = openFileDialog.FileName;
                loadExcelFile(filePath);
            }
        }
        private void InitializeDataGridView()
        {
            dssinhvien_datagridview.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dssinhvien_datagridview.Columns.Add("Column1", "MSSV");
            dssinhvien_datagridview.Columns.Add("Column2", "Họ tên");
        }

        private void loadExcelFile(string filePath)
        {
            try
            {
                FileInfo fileInfo = new FileInfo(filePath);
                using (ExcelPackage package = new ExcelPackage(fileInfo))
                {
                    ExcelWorksheet worksheet = package.Workbook.Worksheets[0];

                    if (worksheet.Dimension == null)
                    {
                        MessageBox.Show("File trống hoặc bị lỗi, vui lòng thử lại ọn hoặc chọn file khác");
                        return;
                    }

                    dssinhvien_datagridview.Rows.Clear();
                    InitializeDataGridView();

                    int totalRows = worksheet.Dimension.Rows;
                    
                    int startRow = 0;
                    for (int row = 1; row <= totalRows; row++)
                    {
                        if (worksheet.Cells[row, 1].Text.Equals("MSSV", StringComparison.OrdinalIgnoreCase))
                        {
                            startRow = row + 1;
                            break;
                        }
                    }

                    if (startRow == 0 || startRow > totalRows)
                    {
                        MessageBox.Show("Vui lòng định dạng lại file. Cột A có tên là MSSV, theo sau là cột chứa họ lót và cột chứa tên sinh viên");
                        return;
                    }

                    for (int row = startRow; row <= totalRows; row++)
                    {
                        object[] rowData = new object[2];
                        bool isRowEmpty = false;

                        if (worksheet.Cells[row, 2].Merge)
                        {
                            continue;
                        }

                        rowData[0] = worksheet.Cells[row, 1].Text;
                        rowData[1] = worksheet.Cells[row, 2].Text + " " + worksheet.Cells[row, 3].Text;

                        if (string.IsNullOrWhiteSpace(worksheet.Cells[row, 1].Text.ToString()))
                        {
                            isRowEmpty = true;
                        }

                        if (isRowEmpty)
                        {
                            break;
                        }
                        else
                        {
                            dssinhvien_datagridview.Rows.Add(rowData);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Lỗi đọc file: {ex.Message}");
            }
        }

        private void thoat_btn_Click(object sender, EventArgs e)
        {
            HeThongDiemDanh hethondiemdanh = new HeThongDiemDanh();
            this.Close();
            hethondiemdanh.Show();
        }

        private void dslop_combobox_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                connect.Open();
                String danhSachNhom = "SELECT * FROM NHOM WHERE MALOP = @malop";
                using (SqlCommand cmd = new SqlCommand(danhSachNhom, connect))
                {
                    cmd.Parameters.AddWithValue("@malop", dslop_combobox.SelectedItem.ToString());
                    SqlDataReader sqlDataReader = cmd.ExecuteReader();

                    dsnhom_combobox.Items.Clear();

                    while (sqlDataReader.Read())
                    {
                        string maNhom = sqlDataReader["TENNHOM"].ToString();
                        dsnhom_combobox.Items.Add(maNhom);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi kết nối: " + ex.Message);
            }
            finally
            {
                connect.Close();
            }
        }

        private void luu_btn_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(dslop_combobox.SelectedItem?.ToString()) ||
                string.IsNullOrEmpty(dsnhom_combobox.SelectedItem?.ToString()))
            {
                MessageBox.Show("Vui lòng chọn lớp và nhóm");
            }

            else if (dssinhvien_datagridview.Rows.Count == 0 || dssinhvien_datagridview.Rows[0].IsNewRow)
            {
                MessageBox.Show("Vui lòng tải lên danh sách sinh viên");
            }
            else 
            {
                try
                {
                    connect.Open();
                    SqlTransaction sqlTransaction = connect.BeginTransaction();

                    String themSinhVien = @"MERGE INTO SINHVIEN AS TARGET
                                    USING (SELECT @mssv AS MSSV, @hoten AS HOTEN) AS SOURCE
                                    ON TARGET.MSSV = SOURCE.MSSV
                                    WHEN NOT MATCHED BY TARGET THEN
                                         INSERT (MSSV,HOTEN) VALUES (SOURCE.MSSV,SOURCE.HOTEN);";
                    String themHocPhan = @"MERGE INTO HOCPHAN AS TARGET
                                    USING (SELECT @mssv AS MSSV, @malop AS MALOP, @tennhom AS TENNHOM) AS SOURCE
                                    ON TARGET.MSSV = SOURCE.MSSV AND TARGET.MALOP = SOURCE.MALOP
                                    WHEN NOT MATCHED BY TARGET THEN
                                         INSERT (MSSV,MALOP,TENNHOM) VALUES (SOURCE.MSSV,SOURCE.MALOP,SOURCE.TENNHOM);";

                    foreach (DataGridViewRow row in dssinhvien_datagridview.Rows)
                    {
                        if (!row.IsNewRow)
                        {
                            using (SqlCommand cmdSinhVien = new SqlCommand(themSinhVien, connect, sqlTransaction))
                            {
                                cmdSinhVien.Parameters.AddWithValue("@mssv", row.Cells[0].Value.ToString());
                                cmdSinhVien.Parameters.AddWithValue("@hoten", row.Cells[1].Value.ToString());
                                cmdSinhVien.ExecuteNonQuery();
                            }
                            using(SqlCommand cmdHocPhan = new SqlCommand(themHocPhan, connect, sqlTransaction))
                            {
                                cmdHocPhan.Parameters.AddWithValue("@mssv", row.Cells[0].Value.ToString());
                                cmdHocPhan.Parameters.AddWithValue("@malop", dslop_combobox.SelectedItem.ToString());
                                cmdHocPhan.Parameters.AddWithValue("@tennhom", dsnhom_combobox.SelectedItem.ToString());
                                int rowsAffected = cmdHocPhan.ExecuteNonQuery();

                                if (rowsAffected == 0)
                                {   
                                    sqlTransaction.Rollback();
                                    throw new Exception($"Sinh viên {row.Cells[1].Value.ToString()} (MSSV: {row.Cells[0].Value.ToString()}) đã ở nhóm {dsnhom_combobox.SelectedItem.ToString()} của lớp {dslop_combobox.SelectedItem.ToString()}.");
                                }
                            }
                        }
                    }
                    sqlTransaction.Commit();
                    MessageBox.Show("Đã thêm sinh viên vào danh sách");
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
                finally
                {
                    connect.Close();
                }
            }
            
        }
    }
}
