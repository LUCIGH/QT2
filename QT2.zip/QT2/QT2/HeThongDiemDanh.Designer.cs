﻿namespace QT2
{
    partial class HeThongDiemDanh
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            qr_button = new Button();
            tailai_button = new Button();
            xem_btn = new Button();
            taolop_btn = new Button();
            lop_combobox = new ComboBox();
            nhom_combobox = new ComboBox();
            label1 = new Label();
            label2 = new Label();
            danhsachsinhvien_datagridview = new DataGridView();
            thoat_btn = new Button();
            suathongtin_btn = new Button();
            ((System.ComponentModel.ISupportInitialize)danhsachsinhvien_datagridview).BeginInit();
            SuspendLayout();
            // 
            // qr_button
            // 
            qr_button.Location = new Point(812, 61);
            qr_button.Name = "qr_button";
            qr_button.Size = new Size(112, 37);
            qr_button.TabIndex = 0;
            qr_button.Text = "QR";
            qr_button.UseVisualStyleBackColor = true;
            qr_button.Click += qr_button_Click;
            // 
            // tailai_button
            // 
            tailai_button.Location = new Point(576, 138);
            tailai_button.Name = "tailai_button";
            tailai_button.Size = new Size(112, 34);
            tailai_button.TabIndex = 1;
            tailai_button.Text = "Tải lại";
            tailai_button.UseVisualStyleBackColor = true;
            tailai_button.Click += tailai_button_Click;
            // 
            // xem_btn
            // 
            xem_btn.Location = new Point(576, 64);
            xem_btn.Name = "xem_btn";
            xem_btn.Size = new Size(112, 34);
            xem_btn.TabIndex = 2;
            xem_btn.Text = "Xem";
            xem_btn.UseVisualStyleBackColor = true;
            xem_btn.Click += xem_btn_Click;
            // 
            // taolop_btn
            // 
            taolop_btn.Location = new Point(694, 64);
            taolop_btn.Name = "taolop_btn";
            taolop_btn.Size = new Size(112, 34);
            taolop_btn.TabIndex = 3;
            taolop_btn.Text = "Tạo lớp";
            taolop_btn.UseVisualStyleBackColor = true;
            taolop_btn.Click += taolop_btn_Click;
            // 
            // lop_combobox
            // 
            lop_combobox.FormattingEnabled = true;
            lop_combobox.Location = new Point(163, 64);
            lop_combobox.Name = "lop_combobox";
            lop_combobox.Size = new Size(407, 33);
            lop_combobox.TabIndex = 4;
            lop_combobox.SelectedIndexChanged += lop_combobox_SelectedIndexChanged;
            // 
            // nhom_combobox
            // 
            nhom_combobox.FormattingEnabled = true;
            nhom_combobox.Location = new Point(163, 140);
            nhom_combobox.Name = "nhom_combobox";
            nhom_combobox.Size = new Size(407, 33);
            nhom_combobox.TabIndex = 5;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(49, 72);
            label1.Name = "label1";
            label1.Size = new Size(42, 25);
            label1.TabIndex = 6;
            label1.Text = "Lớp";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(49, 148);
            label2.Name = "label2";
            label2.Size = new Size(62, 25);
            label2.TabIndex = 7;
            label2.Text = "Nhóm";
            // 
            // danhsachsinhvien_datagridview
            // 
            danhsachsinhvien_datagridview.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            danhsachsinhvien_datagridview.Location = new Point(49, 203);
            danhsachsinhvien_datagridview.Name = "danhsachsinhvien_datagridview";
            danhsachsinhvien_datagridview.RowHeadersWidth = 62;
            danhsachsinhvien_datagridview.Size = new Size(892, 332);
            danhsachsinhvien_datagridview.TabIndex = 8;
            // 
            // thoat_btn
            // 
            thoat_btn.Location = new Point(812, 21);
            thoat_btn.Name = "thoat_btn";
            thoat_btn.Size = new Size(112, 34);
            thoat_btn.TabIndex = 9;
            thoat_btn.Text = "Thoát";
            thoat_btn.UseVisualStyleBackColor = true;
            thoat_btn.Click += thoat_btn_Click;
            // 
            // suathongtin_btn
            // 
            suathongtin_btn.Location = new Point(694, 140);
            suathongtin_btn.Name = "suathongtin_btn";
            suathongtin_btn.Size = new Size(181, 33);
            suathongtin_btn.TabIndex = 10;
            suathongtin_btn.Text = "Sửa thông tin";
            suathongtin_btn.UseVisualStyleBackColor = true;
            suathongtin_btn.Click += suathongtin_btn_Click;
            // 
            // HeThongDiemDanh
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(977, 561);
            Controls.Add(suathongtin_btn);
            Controls.Add(thoat_btn);
            Controls.Add(danhsachsinhvien_datagridview);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(nhom_combobox);
            Controls.Add(lop_combobox);
            Controls.Add(taolop_btn);
            Controls.Add(xem_btn);
            Controls.Add(tailai_button);
            Controls.Add(qr_button);
            Name = "HeThongDiemDanh";
            Text = "HeThongDiemDanh";
            Load += HeThongDiemDanh_Load;
            ((System.ComponentModel.ISupportInitialize)danhsachsinhvien_datagridview).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button qr_button;
        private Button tailai_button;
        private Button xem_btn;
        private Button taolop_btn;
        private ComboBox lop_combobox;
        private ComboBox nhom_combobox;
        private Label label1;
        private Label label2;
        private DataGridView danhsachsinhvien_datagridview;
        private Button thoat_btn;
        private Button suathongtin_btn;
    }
}