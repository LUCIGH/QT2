﻿namespace QT2
{
    public partial class ManHinhQR : Form
    {
        public ManHinhQR()
        {
            InitializeComponent();
        }

        private void QR_cancel_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
