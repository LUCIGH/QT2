﻿using System.Data;
using System.Data.SqlClient;
using Google.Apis.Auth.OAuth2;
using Google.Apis.Services;
using Google.Apis.Sheets.v4;
using Google.Apis.Util.Store;
using System.Globalization;

namespace QT2
{
    public partial class HeThongDiemDanh : Form
    {
        private static readonly HttpClient httpClient = new HttpClient();
        SqlConnection connect = new SqlConnection(@"Data Source=lucigh\mssqlserver01;Initial Catalog=PHANMEMDIEMDANH;Integrated Security=True;");
        public HeThongDiemDanh()
        {
            InitializeComponent();
        }

        private void qr_button_Click(object sender, EventArgs e)
        {
            ManHinhQR manhinhqr = new ManHinhQR();
            manhinhqr.Show();
        }

        private void taolop_btn_Click(object sender, EventArgs e)
        {
            TaoLop taolop = new TaoLop();
            taolop.Show();
            this.Hide();
        }

        private void thoat_btn_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void suathongtin_btn_Click(object sender, EventArgs e)
        {
            DanhSachSinhVien ds = new DanhSachSinhVien();
            ds.Show();
            this.Hide();
        }

        private void HeThongDiemDanh_Load(object sender, EventArgs e)
        {
            if (CurrentUser.curUser == null)
            {
                DangNhap dangNhap = new DangNhap();
                dangNhap.ShowDialog();
                if (CurrentUser.curUser != null)
                {
                    hienThiThongTin();
                }
            }
            else
            {
                hienThiThongTin();
            }
        }
        private void hienThiThongTin()
        {
            try
            {
                connect.Open();
                String danhSachLop = "SELECT * FROM LOP WHERE ID = @currentuser";
                using (SqlCommand cmd = new SqlCommand(danhSachLop, connect))
                {
                    cmd.Parameters.AddWithValue("@currentuser", CurrentUser.curUser.id);
                    SqlDataReader sqlDataReader = cmd.ExecuteReader();
                    if (sqlDataReader.HasRows)
                    {
                        while (sqlDataReader.Read())
                        {
                            string malop = sqlDataReader["MALOP"].ToString();
                            lop_combobox.Items.Add(malop);
                        }
                    }
                };
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi kết nối: " + ex.Message);
            }
            finally
            {
                connect.Close();
            }
        }

        private void lop_combobox_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                connect.Open();
                String danhSachNhom = "SELECT * FROM NHOM WHERE MALOP = @malop";
                using (SqlCommand cmd = new SqlCommand(danhSachNhom, connect))
                {
                    cmd.Parameters.AddWithValue("@malop", lop_combobox.SelectedItem.ToString());
                    SqlDataReader sqlDataReader = cmd.ExecuteReader();

                    nhom_combobox.Items.Clear();

                    while (sqlDataReader.Read())
                    {
                        string maNhom = sqlDataReader["TENNHOM"].ToString();
                        nhom_combobox.Items.Add(maNhom);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi kết nối: " + ex.Message);
            }
            finally
            {
                connect.Close();
            }
        }

        private void tailai_button_Click(object sender, EventArgs e)
        {
            load();
        }

        private async void load()
        {
            try
            {
                connect.Open();

                string[] Scopes = { SheetsService.Scope.Spreadsheets };
                var service = new SheetsService(new BaseClientService.Initializer()
                {
                    HttpClientInitializer = GoogleWebAuthorizationBroker.AuthorizeAsync(
                        new ClientSecrets
                        {
                            ClientId = "705533801911-nsv29rm71nhjgvi4nue2s4uavfdhp0js.apps.googleusercontent.com",
                            ClientSecret = "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"
                        },
                        Scopes,
                        "user",
                        CancellationToken.None,
                        new FileDataStore("MyAppsToken")).Result,
                    ApplicationName = "Google Sheets API .NET Quickstart",
                });

                var values = service.Spreadsheets.Values.Get("1Fyy9HFkz6tvyUpF2eac1OQfzIB-t7DoivG-hxikgvjE", $"{"Responses"}!A2:G").Execute().Values;

                if (values == null || values.Count == 0)
                {
                    MessageBox.Show("Hiện chưa có câu trả lời");
                    return;
                }

                int saiThongTin = 0;

                foreach (var Column in values)
                {
                    if (Column.Count >= 7)
                    {
                        if (!email_MSSV_matching(Column[1].ToString(), Column[3].ToString()))
                        {
                            continue;
                        }

                        String diemDanh = @"
                                            IF EXISTS (SELECT 1 FROM SINHVIEN WHERE MSSV = @mssv) AND
                                               EXISTS (SELECT 1 FROM HOCPHAN WHERE MALOP = @malop)
                                            BEGIN
                                                INSERT INTO DIEMDANH (MSSV, MALOP, NGAYDIEMDANH, KINHDO, VIDO) 
                                                VALUES (@mssv, @malop, @ngaydiemdanh, @kinhdo, @vido);
                                            END";

                        using (SqlCommand cmd = new SqlCommand(diemDanh, connect))
                        {
                            cmd.Parameters.AddWithValue("@mssv", Column[3].ToString());
                            cmd.Parameters.AddWithValue("@malop", Column[4].ToString());

                            DateTime submissionTime = DateTime.ParseExact(Column[0].ToString(), "dd/MM/yyyy H:mm:ss", CultureInfo.InvariantCulture);
                            cmd.Parameters.Add("@ngaydiemdanh", SqlDbType.DateTime).Value = submissionTime;
                            cmd.Parameters.AddWithValue("@kinhdo", float.Parse(Column[5].ToString().Replace(",", ".")));
                            cmd.Parameters.AddWithValue("@vido", float.Parse(Column[6].ToString().Replace(",", ".")));

                            if (cmd.ExecuteNonQuery() <= 0)
                            {
                                saiThongTin++;
                            }
                        };
                    }
                    else
                    {
                        saiThongTin += 1;
                    }
                }

                await DeleteRowsFromGoogleSheetAsync();

                if (saiThongTin == 0)
                {
                    MessageBox.Show("Thêm thành công");
                }
                else
                {
                    MessageBox.Show("Có sinh viên nhập sai thông tin, vui lòng kiểm tra lại");
                } 
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
            finally
            {
                connect.Close();
            }
        }

        private bool email_MSSV_matching(string email, string mssv)
        {
            string extractedId = email.Split('@')[0];

            if (extractedId.Equals(mssv, StringComparison.OrdinalIgnoreCase))
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        private async Task DeleteRowsFromGoogleSheetAsync()
        {
            try
            {
                string url = "https://script.google.com/macros/s/AKfycbwk5sxMLdpJMeL3t_Q9ErKjV0xE11h_GQasE5owsvck6UY_kCPv5o58N_QClxqj3UIiCQ/exec";

                var response = await httpClient.PostAsync(url,null);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Exception: " + ex.Message);
            }
        }

        private void xem_btn_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(lop_combobox.SelectedItem?.ToString()) ||
               string.IsNullOrEmpty(nhom_combobox.SelectedItem?.ToString()))
            {
                MessageBox.Show("Vui lòng chọn lớp và nhóm");
                return;
            }

            try
            {
                connect.Open();

                string malop = lop_combobox.SelectedItem.ToString();
                List<DateTime> dates = GetDistinctDates(malop);

                string query = @"
                    SELECT 
                        SV.HOTEN,
                        SV.MSSV";

                int parameterIndex = 0;

                foreach (DateTime date in dates)
                {
                    string formattedDate = date.ToString("dd_MM_yyyy");
                    string dateName = "@date" + parameterIndex;

                    query += $@",
                    COUNT(DISTINCT CASE WHEN CAST(DD.NGAYDIEMDANH AS DATE) = {dateName}
                                    AND DD.VIDO BETWEEN 10.730577 AND 10.733050
                                    AND DD.KINHDO BETWEEN 106.698650 AND 106.699712
                                    THEN 1 END) AS [{formattedDate}]";
                    parameterIndex++;
                }
                query += @",
                            COUNT(DISTINCT CASE
                                WHEN
                                    DD.VIDO BETWEEN 10.730577 AND 10.733050
                                    AND DD.KINHDO BETWEEN 106.698650 AND 106.699712
                                THEN CAST(DD.NGAYDIEMDANH AS DATE)
                                ELSE NULL
                                END) AS TONG";
                query += @"
                    FROM 
                        SINHVIEN SV
                    LEFT JOIN 
                        DIEMDANH DD ON SV.MSSV = DD.MSSV AND DD.MALOP = @malop
                    JOIN 
                        NHOM N ON N.MALOP = @malop
                    WHERE 
                        N.TENNHOM = @tennhom
                    GROUP BY 
                        SV.HOTEN, SV.MSSV;";

                using (SqlCommand cmd = new SqlCommand(query, connect))
                {
                    cmd.Parameters.AddWithValue("@malop", malop);
                    cmd.Parameters.AddWithValue("@tennhom", nhom_combobox.SelectedItem.ToString());

                    parameterIndex = 0;

                    foreach (DateTime date in dates)
                    {
                        cmd.Parameters.Add("@date" + parameterIndex, SqlDbType.Date).Value = date;

                        parameterIndex++;
                    }

                    SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    adapter.Fill(dt);

                    danhsachsinhvien_datagridview.DataSource = null;
                    danhsachsinhvien_datagridview.DataSource = dt;
                    danhsachsinhvien_datagridview.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;

                    int submissionThreshold = 1;

                    foreach (DataGridViewRow row in danhsachsinhvien_datagridview.Rows)
                    {
                        bool totalBelowThreshold = false;

                        for (int i = 2; i < dt.Columns.Count - 1; i++)
                        {
                            if (row.Cells[i].Value != null)
                            {
                                int submissionCount = Convert.ToInt32(row.Cells[i].Value);
                                if (submissionCount < submissionThreshold)
                                {
                                    row.Cells[i].Style.BackColor = Color.Red;
                                }
                            }

                        }

                        if (row.Cells["TONG"].Value != null)
                        {
                            int totalAttendance = Convert.ToInt32(row.Cells["TONG"].Value);

                            if (totalAttendance < submissionThreshold)
                            {
                                totalBelowThreshold = true;
                            }
                        }

                        if (totalBelowThreshold)
                        {
                            row.DefaultCellStyle.BackColor = Color.Red;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                connect.Close();
            }
        }

        private List<DateTime> GetDistinctDates(string malop)
        {
            List<DateTime> dates = new List<DateTime>();

            string query = "SELECT DISTINCT CAST(NGAYDIEMDANH AS DATE) FROM DIEMDANH WHERE MALOP = @malop";

            using (SqlCommand cmd = new SqlCommand(query, connect))
            {
                cmd.Parameters.AddWithValue("@malop", malop);
                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        dates.Add(reader.GetDateTime(0));
                    }
                }
            }

            return dates;
        }
    }
}
