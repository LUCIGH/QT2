﻿namespace QT2
{
    partial class DanhSachSinhVien
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            luu_btn = new Button();
            dsnhom_combobox = new ComboBox();
            dslop_combobox = new ComboBox();
            label1 = new Label();
            chonfile_btn = new Button();
            label2 = new Label();
            label3 = new Label();
            dssinhvien_datagridview = new DataGridView();
            thoat_btn = new Button();
            ((System.ComponentModel.ISupportInitialize)dssinhvien_datagridview).BeginInit();
            SuspendLayout();
            // 
            // luu_btn
            // 
            luu_btn.Location = new Point(170, 552);
            luu_btn.Name = "luu_btn";
            luu_btn.Size = new Size(112, 34);
            luu_btn.TabIndex = 0;
            luu_btn.Text = "Lưu";
            luu_btn.UseVisualStyleBackColor = true;
            luu_btn.Click += luu_btn_Click;
            // 
            // dsnhom_combobox
            // 
            dsnhom_combobox.FormattingEnabled = true;
            dsnhom_combobox.Location = new Point(243, 126);
            dsnhom_combobox.Name = "dsnhom_combobox";
            dsnhom_combobox.Size = new Size(375, 33);
            dsnhom_combobox.TabIndex = 1;
            // 
            // dslop_combobox
            // 
            dslop_combobox.FormattingEnabled = true;
            dslop_combobox.Location = new Point(243, 43);
            dslop_combobox.Name = "dslop_combobox";
            dslop_combobox.Size = new Size(375, 33);
            dslop_combobox.TabIndex = 2;
            dslop_combobox.SelectedIndexChanged += dslop_combobox_SelectedIndexChanged;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(45, 51);
            label1.Name = "label1";
            label1.Size = new Size(42, 25);
            label1.TabIndex = 3;
            label1.Text = "Lớp";
            // 
            // chonfile_btn
            // 
            chonfile_btn.Location = new Point(243, 204);
            chonfile_btn.Name = "chonfile_btn";
            chonfile_btn.Size = new Size(112, 34);
            chonfile_btn.TabIndex = 4;
            chonfile_btn.Text = "Chọn file";
            chonfile_btn.UseVisualStyleBackColor = true;
            chonfile_btn.Click += chonfile_btn_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(45, 134);
            label2.Name = "label2";
            label2.Size = new Size(62, 25);
            label2.TabIndex = 5;
            label2.Text = "Nhóm";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(48, 209);
            label3.Name = "label3";
            label3.Size = new Size(168, 25);
            label3.TabIndex = 6;
            label3.Text = "Danh sách sinh viên";
            // 
            // dssinhvien_datagridview
            // 
            dssinhvien_datagridview.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dssinhvien_datagridview.Location = new Point(48, 253);
            dssinhvien_datagridview.Name = "dssinhvien_datagridview";
            dssinhvien_datagridview.RowHeadersWidth = 62;
            dssinhvien_datagridview.Size = new Size(570, 278);
            dssinhvien_datagridview.TabIndex = 7;
            // 
            // thoat_btn
            // 
            thoat_btn.Location = new Point(316, 552);
            thoat_btn.Name = "thoat_btn";
            thoat_btn.Size = new Size(112, 34);
            thoat_btn.TabIndex = 8;
            thoat_btn.Text = "Thoát";
            thoat_btn.UseVisualStyleBackColor = true;
            thoat_btn.Click += thoat_btn_Click;
            // 
            // DanhSachSinhVien
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(677, 615);
            Controls.Add(thoat_btn);
            Controls.Add(dssinhvien_datagridview);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(chonfile_btn);
            Controls.Add(label1);
            Controls.Add(dslop_combobox);
            Controls.Add(dsnhom_combobox);
            Controls.Add(luu_btn);
            Name = "DanhSachSinhVien";
            Text = "DanhSachSinhVien";
            Load += DanhSachSinhVien_Load;
            ((System.ComponentModel.ISupportInitialize)dssinhvien_datagridview).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button luu_btn;
        private ComboBox dsnhom_combobox;
        private ComboBox dslop_combobox;
        private Label label1;
        private Button chonfile_btn;
        private Label label2;
        private Label label3;
        private DataGridView dssinhvien_datagridview;
        private Button thoat_btn;
    }
}