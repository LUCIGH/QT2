﻿using System.Data.SqlClient;

namespace QT2
{
    public partial class TaoLop : Form
    {
        SqlConnection connect = new SqlConnection(@"Data Source=lucigh\mssqlserver01;Initial Catalog=PHANMEMDIEMDANH;Integrated Security=True;");
        public TaoLop()
        {
            InitializeComponent();
        }

        private void huy_btn_Click(object sender, EventArgs e)
        {
            this.Close();
            HeThongDiemDanh hethongdiemdanh = new HeThongDiemDanh();
            hethongdiemdanh.Show();
        }

        private void them_btn_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrWhiteSpace(manhom_textbox.Text))
            {
                if (dsnhom_cbox.Items.Contains(manhom_textbox.Text))
                {
                    MessageBox.Show("Nhóm đã tồn tại");
                }
                else
                {
                    dsnhom_cbox.Items.Add(manhom_textbox.Text.ToString());
                    manhom_textbox.Text = null;
                }
            }
            else
            {
                MessageBox.Show("Bạn chưa nhập tên nhóm");
            }
        }

        private void xoanhom_btn_Click(object sender, EventArgs e)
        {
            string selectedItem = dsnhom_cbox.SelectedItem.ToString();

            DialogResult dialogResult = MessageBox.Show($"Are you sure you want to delete '{selectedItem}'?", "Delete Item", MessageBoxButtons.YesNo);

            if (dialogResult == DialogResult.Yes)
            {
                dsnhom_cbox.Items.Remove(selectedItem);
                dsnhom_cbox.Text = null;
            }
        }

        private void taolop_btn_Click(object sender, EventArgs e)
        {
            if (malop_textbox.Text == "" || tenlop_textbox.Text == "" || dsnhom_cbox.Items.Count == 0)
            {
                MessageBox.Show("Hãy điền đầy đủ thông tin của bạn", "Error Message", MessageBoxButtons.OK);
            }
            else
            {
                try
                {
                    connect.Open();

                    SqlTransaction sqlTransaction = connect.BeginTransaction();

                    String themLop = @"MERGE INTO LOP AS TARGET
                                    USING (SELECT @malop AS MALOP, @tenlop AS TENLOP) AS SOURCE
                                    ON TARGET.MALOP = SOURCE.MALOP
                                    WHEN NOT MATCHED BY TARGET THEN
                                         INSERT (MALOP,TENLOP,ID) VALUES (SOURCE.MALOP,SOURCE.TENLOP,@id);";
                    String themNhom = "INSERT INTO NHOM (TENNHOM,MALOP) VALUES (@tennhom,@malop)";
                    using (SqlCommand cmd = new SqlCommand(themLop, connect,sqlTransaction))
                    {
                        cmd.Parameters.AddWithValue("@malop", malop_textbox.Text.ToString());
                        cmd.Parameters.AddWithValue("@tenlop", tenlop_textbox.Text.ToString());
                        cmd.Parameters.AddWithValue("@id", CurrentUser.curUser.id);
                        int rowAffected = cmd.ExecuteNonQuery();
                        if (rowAffected < 1)
                        {
                            sqlTransaction.Rollback();
                            throw new Exception("Lớp đã tồn tại");
                        }

                    }
                    foreach (var item in dsnhom_cbox.Items)
                    {
                        using (SqlCommand cmd = new SqlCommand(themNhom, connect, sqlTransaction))
                        {
                            cmd.Parameters.AddWithValue("@tennhom", item.ToString());
                            cmd.Parameters.AddWithValue("@malop", malop_textbox.Text.ToString());
                            int rowAffected = cmd.ExecuteNonQuery();
                            if (rowAffected < 1)
                            {
                                sqlTransaction.Rollback();
                                throw new Exception("Lỗi dữ liệu");
                            }

                        }
                    }

                    sqlTransaction.Commit();
                    MessageBox.Show("Tạo lớp thành công");
                    DanhSachSinhVien danhsachsinhvien = new DanhSachSinhVien();
                    danhsachsinhvien.Show();
                    this.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
                finally
                {
                    connect.Close();
                }
            }

        }
    }
}
