﻿using System.Data;
using System.Data.SqlClient;

namespace QT2
{

    public partial class DangNhap : Form
    {
        SqlConnection connect = new SqlConnection(@"Data Source=lucigh\mssqlserver01;Initial Catalog=PHANMEMDIEMDANH;Integrated Security=True;");
        public DangNhap()
        {
            InitializeComponent();
        }

        private void login_signupHere_Click(object sender, EventArgs e)
        {
            DangKi sForm = new DangKi();
            sForm.ShowDialog();
            this.Hide();
        }

        private void login_exit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void login_btn_Click(object sender, EventArgs e)
        {
            if (login_password.Text == "" || login_username.Text == "")
            {
                MessageBox.Show("Hãy điền đầy đủ thông tin của bạn", "Error Message", MessageBoxButtons.OK);
            }
            else
            {
                string username = login_username.Text;
                string password = login_password.Text;

                CurrentUser.curUser = AuthenticateUser(username, password);

                if (CurrentUser.curUser != null)
                {
                    this.Close();
                }
                else
                {
                    MessageBox.Show("Tên đăng nhập hoặc mật khẩu không chính xác, vui lòng thử lại");
                }
            }
        }

        private void login_showPass_CheckedChanged(object sender, EventArgs e)
        {
            if (login_showPass.Checked)
            {
                login_password.PasswordChar = '\0';
            }
            else
            {
                login_password.PasswordChar = '*';
            }
        }

        private User AuthenticateUser(string username, string password) {
            User user = null;
            try
            {
                connect.Open();

                String selectData = "SELECT * FROM GIANGVIEN WHERE USERNAME = @username and PWD = @pass";

                using (SqlCommand cmd = new SqlCommand(selectData, connect))
                {
                    cmd.Parameters.AddWithValue("@username", login_username.Text);
                    cmd.Parameters.AddWithValue("@pass", login_password.Text);
                    SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                    DataTable table = new DataTable();
                    adapter.Fill(table);

                    if (table.Rows.Count > 0)
                    {
                        user = new User()
                        {
                            id = (int)table.Rows[0]["ID"],
                            tendangnhap = table.Rows[0]["USERNAME"].ToString(),
                            email = table.Rows[0]["EMAIL"].ToString(),
                        };
                    }
                }
            }
            catch (Exception ex)
            {
                {
                    MessageBox.Show("Lỗi kết nối" + ex, "Error Message", MessageBoxButtons.OK);
                }
            }
            finally
            {
                connect.Close();
            }
            return user;
        }
    }
}
