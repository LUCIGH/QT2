﻿namespace QT2
{
    partial class ManHinhQR
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }
        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            panel2 = new Panel();
            QR_cancel = new Label();
            panel3 = new Panel();
            label1 = new Label();
            pictureBox1 = new PictureBox();
            panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // panel2
            // 
            panel2.BackColor = Color.White;
            panel2.Controls.Add(pictureBox1);
            panel2.Controls.Add(QR_cancel);
            panel2.Controls.Add(panel3);
            panel2.Controls.Add(label1);
            panel2.Location = new Point(0, 1);
            panel2.Margin = new Padding(4, 5, 4, 5);
            panel2.Name = "panel2";
            panel2.Size = new Size(1044, 791);
            panel2.TabIndex = 1;
            // 
            // QR_cancel
            // 
            QR_cancel.AutoSize = true;
            QR_cancel.Cursor = Cursors.Hand;
            QR_cancel.Font = new Font("Segoe UI", 14.25F);
            QR_cancel.Location = new Point(994, 14);
            QR_cancel.Margin = new Padding(4, 0, 4, 0);
            QR_cancel.Name = "QR_cancel";
            QR_cancel.Size = new Size(34, 40);
            QR_cancel.TabIndex = 3;
            QR_cancel.Text = "X";
            QR_cancel.Click += QR_cancel_Click;
            // 
            // panel3
            // 
            panel3.BackColor = Color.RosyBrown;
            panel3.Location = new Point(0, 0);
            panel3.Margin = new Padding(4, 5, 4, 5);
            panel3.Name = "panel3";
            panel3.Size = new Size(351, 791);
            panel3.TabIndex = 2;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = SystemColors.Control;
            label1.Font = new Font("Times New Roman", 18F, FontStyle.Bold);
            label1.ForeColor = Color.RosyBrown;
            label1.Location = new Point(567, 528);
            label1.Margin = new Padding(4, 0, 4, 0);
            label1.Name = "label1";
            label1.Size = new Size(285, 41);
            label1.TabIndex = 1;
            label1.Text = "Hãy quét mã QR ";
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.QR;
            pictureBox1.Location = new Point(550, 201);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(302, 305);
            pictureBox1.TabIndex = 4;
            pictureBox1.TabStop = false;
            // 
            // ManHinhQR
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1044, 791);
            Controls.Add(panel2);
            FormBorderStyle = FormBorderStyle.None;
            Margin = new Padding(4, 5, 4, 5);
            Name = "ManHinhQR";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "ManhinhQR";
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
        }

        private Panel panel2;
        private Label label1;
        private Panel panel3;
        private Label QR_cancel;
        private PictureBox pictureBox1;
    }
}