﻿namespace QT2
{
    partial class DangKi
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            panel1 = new Panel();
            signup_exit = new Label();
            signup_email = new TextBox();
            label7 = new Label();
            signup_loginHere = new Label();
            label5 = new Label();
            signup_showPass = new CheckBox();
            signup_btn = new Button();
            signup_password = new TextBox();
            signup_username = new TextBox();
            label4 = new Label();
            label3 = new Label();
            label1 = new Label();
            panel2 = new Panel();
            panel4 = new Panel();
            label2 = new Label();
            panel1.SuspendLayout();
            panel2.SuspendLayout();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackColor = Color.White;
            panel1.Controls.Add(signup_exit);
            panel1.Controls.Add(signup_email);
            panel1.Controls.Add(label7);
            panel1.Controls.Add(signup_loginHere);
            panel1.Controls.Add(label5);
            panel1.Controls.Add(signup_showPass);
            panel1.Controls.Add(signup_btn);
            panel1.Controls.Add(signup_password);
            panel1.Controls.Add(signup_username);
            panel1.Controls.Add(label4);
            panel1.Controls.Add(label3);
            panel1.Controls.Add(label1);
            panel1.Controls.Add(panel2);
            panel1.Location = new Point(-11, -4);
            panel1.Margin = new Padding(4, 5, 4, 5);
            panel1.Name = "panel1";
            panel1.Size = new Size(1044, 791);
            panel1.TabIndex = 1;
            // 
            // signup_exit
            // 
            signup_exit.AutoSize = true;
            signup_exit.Cursor = Cursors.Hand;
            signup_exit.Font = new Font("Times New Roman", 14.25F);
            signup_exit.Location = new Point(982, 46);
            signup_exit.Margin = new Padding(4, 0, 4, 0);
            signup_exit.Name = "signup_exit";
            signup_exit.Size = new Size(36, 33);
            signup_exit.TabIndex = 12;
            signup_exit.Text = "X";
            signup_exit.Click += signup_exit_Click;
            // 
            // signup_email
            // 
            signup_email.Location = new Point(666, 301);
            signup_email.Margin = new Padding(4, 5, 4, 5);
            signup_email.Name = "signup_email";
            signup_email.Size = new Size(348, 31);
            signup_email.TabIndex = 11;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Times New Roman", 12F);
            label7.Location = new Point(492, 304);
            label7.Margin = new Padding(4, 0, 4, 0);
            label7.Name = "label7";
            label7.Size = new Size(68, 27);
            label7.TabIndex = 10;
            label7.Text = "Email";
            // 
            // signup_loginHere
            // 
            signup_loginHere.AutoSize = true;
            signup_loginHere.Cursor = Cursors.Hand;
            signup_loginHere.Font = new Font("Times New Roman", 9.75F, FontStyle.Bold);
            signup_loginHere.Location = new Point(790, 704);
            signup_loginHere.Margin = new Padding(4, 0, 4, 0);
            signup_loginHere.Name = "signup_loginHere";
            signup_loginHere.Size = new Size(161, 23);
            signup_loginHere.TabIndex = 9;
            signup_loginHere.Text = "Đăng nhập tại đây";
            signup_loginHere.Click += signup_loginHere_Click;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Times New Roman", 9.75F);
            label5.Location = new Point(592, 704);
            label5.Margin = new Padding(4, 0, 4, 0);
            label5.Name = "label5";
            label5.Size = new Size(179, 22);
            label5.TabIndex = 8;
            label5.Text = "Bạn đã có tài khoản ?";
            // 
            // signup_showPass
            // 
            signup_showPass.AutoSize = true;
            signup_showPass.ForeColor = Color.DarkGray;
            signup_showPass.Location = new Point(666, 476);
            signup_showPass.Margin = new Padding(4, 5, 4, 5);
            signup_showPass.Name = "signup_showPass";
            signup_showPass.Size = new Size(154, 29);
            signup_showPass.TabIndex = 7;
            signup_showPass.Text = "Hiện Mật Khẩu";
            signup_showPass.UseVisualStyleBackColor = true;
            signup_showPass.CheckedChanged += signup_showPass_CheckedChanged;
            // 
            // signup_btn
            // 
            signup_btn.BackColor = Color.FromArgb(192, 0, 0);
            signup_btn.Font = new Font("Times New Roman", 12F, FontStyle.Bold);
            signup_btn.ForeColor = Color.White;
            signup_btn.Location = new Point(689, 545);
            signup_btn.Margin = new Padding(4, 5, 4, 5);
            signup_btn.Name = "signup_btn";
            signup_btn.Size = new Size(176, 61);
            signup_btn.TabIndex = 6;
            signup_btn.Text = "Đăng Ký";
            signup_btn.UseVisualStyleBackColor = false;
            signup_btn.Click += signup_btn_Click;
            // 
            // signup_password
            // 
            signup_password.Location = new Point(666, 429);
            signup_password.Margin = new Padding(4, 5, 4, 5);
            signup_password.Name = "signup_password";
            signup_password.Size = new Size(348, 31);
            signup_password.TabIndex = 5;
            // 
            // signup_username
            // 
            signup_username.Location = new Point(666, 359);
            signup_username.Margin = new Padding(4, 5, 4, 5);
            signup_username.Name = "signup_username";
            signup_username.Size = new Size(348, 31);
            signup_username.TabIndex = 4;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Times New Roman", 12F);
            label4.Location = new Point(492, 431);
            label4.Margin = new Padding(4, 0, 4, 0);
            label4.Name = "label4";
            label4.Size = new Size(109, 27);
            label4.TabIndex = 3;
            label4.Text = "Mật Khẩu";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Times New Roman", 12F);
            label3.Location = new Point(492, 365);
            label3.Margin = new Padding(4, 0, 4, 0);
            label3.Name = "label3";
            label3.Size = new Size(164, 27);
            label3.TabIndex = 2;
            label3.Text = "Tên Đăng Nhập";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Times New Roman", 27.75F, FontStyle.Bold);
            label1.ForeColor = Color.Firebrick;
            label1.Location = new Point(634, 161);
            label1.Margin = new Padding(4, 0, 4, 0);
            label1.Name = "label1";
            label1.Size = new Size(241, 63);
            label1.TabIndex = 1;
            label1.Text = "Đăng Ký";
            // 
            // panel2
            // 
            panel2.BackColor = Color.FromArgb(192, 0, 0);
            panel2.Controls.Add(panel4);
            panel2.Controls.Add(label2);
            panel2.Location = new Point(0, 0);
            panel2.Margin = new Padding(4, 5, 4, 5);
            panel2.Name = "panel2";
            panel2.Size = new Size(471, 791);
            panel2.TabIndex = 0;
            // 
            // panel4
            // 
            panel4.Location = new Point(109, 161);
            panel4.Margin = new Padding(4, 5, 4, 5);
            panel4.Name = "panel4";
            panel4.Size = new Size(254, 132);
            panel4.TabIndex = 3;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Times New Roman", 13.8F, FontStyle.Bold);
            label2.ForeColor = Color.White;
            label2.Location = new Point(40, 358);
            label2.Margin = new Padding(4, 0, 4, 0);
            label2.Name = "label2";
            label2.Size = new Size(383, 32);
            label2.TabIndex = 2;
            label2.Text = "Hệ Thống Quản Lí Điểm Danh";
            label2.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // DangKi
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1032, 726);
            Controls.Add(panel1);
            FormBorderStyle = FormBorderStyle.None;
            Margin = new Padding(4, 5, 4, 5);
            Name = "DangKi";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "DangKy";
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            ResumeLayout(false);
        }

        private Panel panel1;
        private Label signup_loginHere;
        private Label label5;
        private CheckBox signup_showPass;
        private Button signup_btn;
        private TextBox signup_password;
        private TextBox signup_username;
        private Label label4;
        private Label label3;
        private Label label1;
        private Panel panel2;
        private TextBox signup_email;
        private Label label7;
        private Label signup_exit;
        private Panel panel4;
        private Label label2;
    }
}