﻿namespace QT2
{
    partial class TaoLop
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            taolop_btn = new Button();
            label1 = new Label();
            tenlop_textbox = new TextBox();
            label3 = new Label();
            dsnhom_cbox = new ComboBox();
            them_btn = new Button();
            label4 = new Label();
            manhom_textbox = new TextBox();
            huy_btn = new Button();
            xoanhom_btn = new Button();
            label5 = new Label();
            malop_textbox = new TextBox();
            SuspendLayout();
            // 
            // taolop_btn
            // 
            taolop_btn.Location = new Point(178, 283);
            taolop_btn.Name = "taolop_btn";
            taolop_btn.Size = new Size(112, 34);
            taolop_btn.TabIndex = 0;
            taolop_btn.Text = "Tạo lớp";
            taolop_btn.UseVisualStyleBackColor = true;
            taolop_btn.Click += taolop_btn_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(34, 27);
            label1.Name = "label1";
            label1.Size = new Size(69, 25);
            label1.TabIndex = 2;
            label1.Text = "Tên lớp";
            // 
            // tenlop_textbox
            // 
            tenlop_textbox.Location = new Point(246, 27);
            tenlop_textbox.Name = "tenlop_textbox";
            tenlop_textbox.Size = new Size(330, 31);
            tenlop_textbox.TabIndex = 3;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(34, 206);
            label3.Name = "label3";
            label3.Size = new Size(146, 25);
            label3.TabIndex = 5;
            label3.Text = "Danh sách nhóm";
            // 
            // dsnhom_cbox
            // 
            dsnhom_cbox.FormattingEnabled = true;
            dsnhom_cbox.Location = new Point(246, 198);
            dsnhom_cbox.Name = "dsnhom_cbox";
            dsnhom_cbox.Size = new Size(124, 33);
            dsnhom_cbox.TabIndex = 6;
            // 
            // them_btn
            // 
            them_btn.Location = new Point(388, 198);
            them_btn.Name = "them_btn";
            them_btn.Size = new Size(91, 34);
            them_btn.TabIndex = 7;
            them_btn.Text = "Thêm";
            them_btn.UseVisualStyleBackColor = true;
            them_btn.Click += them_btn_Click;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(34, 130);
            label4.Name = "label4";
            label4.Size = new Size(90, 25);
            label4.TabIndex = 8;
            label4.Text = "Tên nhóm";
            // 
            // manhom_textbox
            // 
            manhom_textbox.Location = new Point(246, 124);
            manhom_textbox.Name = "manhom_textbox";
            manhom_textbox.Size = new Size(330, 31);
            manhom_textbox.TabIndex = 9;
            // 
            // huy_btn
            // 
            huy_btn.Location = new Point(306, 283);
            huy_btn.Name = "huy_btn";
            huy_btn.Size = new Size(112, 34);
            huy_btn.TabIndex = 10;
            huy_btn.Text = "Hủy";
            huy_btn.UseVisualStyleBackColor = true;
            huy_btn.Click += huy_btn_Click;
            // 
            // xoanhom_btn
            // 
            xoanhom_btn.Location = new Point(485, 197);
            xoanhom_btn.Name = "xoanhom_btn";
            xoanhom_btn.Size = new Size(91, 34);
            xoanhom_btn.TabIndex = 11;
            xoanhom_btn.Text = "Xóa";
            xoanhom_btn.UseVisualStyleBackColor = true;
            xoanhom_btn.Click += xoanhom_btn_Click;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(34, 81);
            label5.Name = "label5";
            label5.Size = new Size(72, 25);
            label5.TabIndex = 13;
            label5.Text = "Mã Lớp";
            // 
            // malop_textbox
            // 
            malop_textbox.Location = new Point(246, 78);
            malop_textbox.Name = "malop_textbox";
            malop_textbox.Size = new Size(330, 31);
            malop_textbox.TabIndex = 14;
            // 
            // TaoLop
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(613, 347);
            Controls.Add(malop_textbox);
            Controls.Add(label5);
            Controls.Add(xoanhom_btn);
            Controls.Add(huy_btn);
            Controls.Add(manhom_textbox);
            Controls.Add(label4);
            Controls.Add(them_btn);
            Controls.Add(dsnhom_cbox);
            Controls.Add(label3);
            Controls.Add(tenlop_textbox);
            Controls.Add(label1);
            Controls.Add(taolop_btn);
            Name = "TaoLop";
            Text = "TaoLop";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button taolop_btn;
        private Label label1;
        private TextBox tenlop_textbox;
        private Label label3;
        private ComboBox dsnhom_cbox;
        private Button them_btn;
        private Label label4;
        private TextBox manhom_textbox;
        private Button huy_btn;
        private Button xoanhom_btn;
        private Label label5;
        private TextBox malop_textbox;
    }
}